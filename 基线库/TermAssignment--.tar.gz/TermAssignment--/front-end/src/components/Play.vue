<template>
 <!--公告-->
  <section class="ctD-wrap">
    <img class="workImg" src="@/assets/workPlace1.jpg" />
  </section>

</template>

<script>
export default {
  created () {

  },
  mounted () {
    
  }
  
}
    
</script>

<style scoped>
.workImg {
  z-index: -1;
  display: block;
  width: 900px;
  height: 460px;
}
.ctD {
  display: block;
  z-index: 1;
}
</style>
