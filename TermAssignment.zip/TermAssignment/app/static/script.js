function test(){
    alert('i am js');
}