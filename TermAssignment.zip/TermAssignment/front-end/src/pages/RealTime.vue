<template>
  <v-container>
    <div class="player">
      <img src="">
    </div>
  </v-container>
</template>

<script>
  // custom skin css
  // require styles
import 'video.js/dist/video-js.css'

export default {
  components: {
    
  },
  data() {
    return {
    }
  }
    
  }
</script>