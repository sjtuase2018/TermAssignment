<template>
  <v-container align-center="center">
    <h1>This is an about page</h1>
    <h1>姓名：小明</h1>
    <h1>权限：管理员</h1>
  </v-container>
</template>